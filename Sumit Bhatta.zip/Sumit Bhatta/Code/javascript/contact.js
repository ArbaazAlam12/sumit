function isEmail(email){
    return /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(email);
}
function setErrorFor(input, message) {
    const formControl = input.parentElement; 
    const small = formControl.querySelector('small'); 
    small.innerText = message;
    formControl.className = 'form-control error';
}
function setSuccessFor(input) {
    const formControl = input.parentElement; 
    formControl.className = 'form-control success';
}

function sendMail() {
    const username = document.getElementById('username');
    const email = document.getElementById('email');
    const contact = document.getElementById('contact');
    const message = document.getElementById('message');
    const usernameValue = username.value.trim();
    const emailValue = email.value.trim();
    const contactValue = contact.value.trim();
    const messageValue = message.value.trim();

    setErrorFor(username, '');
    setErrorFor(contact, '');
    setErrorFor(message, '');
    setErrorFor(email, '');

    if (
        usernameValue === '' ||
        emailValue === '' ||
        contactValue === '' ||
        messageValue === '' ||
        !isEmail(emailValue)
    ) {
        setErrorFor(username, 'Name cannot be blank');
        setErrorFor(contact, 'Contact cannot be blank');
        setErrorFor(message, 'Message cannot be blank');
        if (emailValue === '') {
            setErrorFor(email, 'Email cannot be blank');
        } else if (!isEmail(emailValue)) {
            setErrorFor(email, 'Email should be valid');
        }
    } else {
        emailjs.init("P1R3w-jJfpfiZPRYw");
        const params = {
            username: usernameValue,
            email: emailValue,
            message: messageValue,
            contact: contactValue
        };

        const serviceID = "service_hnikp0s";
        const templateID = "template_njxqzgc";

        emailjs.send(serviceID, templateID, params)
            .then((response) => {
                console.log("Email sent successfully:", response);
                alert("Your message was sent successfully.");
                username.value = "";
                email.value = "";
                message.value = "";
                contact.value = "";
                setSuccessFor(username);
                setSuccessFor(email);
                setSuccessFor(contact);
                setSuccessFor(message);
            })
            .catch((error) => {
                console.error("Email sending failed:", error);
                alert("An error occurred while sending the email.");
            });
    }
}
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('form');
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        checkInputs();
    });
});

